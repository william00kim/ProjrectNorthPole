
// string to dict

function str_toDict(str){
    str = str.replace(/'/g, `"`);
    str = JSON.parse(str);
    str = Object.values(str);
    return str;
}

// string to num

function str_toNum(str){
    str = str.replace(/,/g, "");
    str = Number(str);
    return str;
}

// 메뉴바 슬라이드

function bot(menu){
    if (menu == 'main'){
        document.getElementById("menu_bot").style.left = "0px";
        document.getElementById("main").style.color = "#000000";
        document.getElementById("news").style.color = "#c8c8c8";
        document.getElementById("corp").style.color = "#c8c8c8";
        document.getElementById("inve").style.color = "#c8c8c8";

        setTimeout(function(){location.href = "/main"}, 200);
    }
    if (menu == 'news'){
        document.getElementById("menu_bot").style.left = "205px";
        document.getElementById("main").style.color = "#c8c8c8";
        document.getElementById("news").style.color = "#000000";
        document.getElementById("corp").style.color = "#c8c8c8";
        document.getElementById("inve").style.color = "#c8c8c8";

        setTimeout(function(){location.href = "/news"}, 200);
    }
    if (menu == 'corp'){
        document.getElementById("menu_bot").style.left = "410px";
        document.getElementById("main").style.color = "#c8c8c8";
        document.getElementById("news").style.color = "#c8c8c8";
        document.getElementById("corp").style.color = "#000000";
        document.getElementById("inve").style.color = "#c8c8c8";

        setTimeout(function(){location.href = "/corp"}, 200);
    }
    if (menu == 'inve'){
        document.getElementById("menu_bot").style.left = "615px";
        document.getElementById("main").style.color = "#c8c8c8";
        document.getElementById("news").style.color = "#c8c8c8";
        document.getElementById("corp").style.color = "#c8c8c8";
        document.getElementById("inve").style.color = "#000000";

        setTimeout(function(){location.href = "/inve"}, 200);
    }
}



// corp 회사정보 검색 애니메이션

function corp_search(){
    document.getElementById("search_frame").style.marginTop = "20px";
}

// corp_data 창에서 표, 그래프 제어하는 버튼

function Display(a){
    if(a == 'Gra'){
    document.getElementById("corp_data").style.display = "block";
    document.getElementById("Gra").style.backgroundColor = "#ff6a00";
    document.getElementById("Gra").style.borderColor = "#ff6a00";
    document.getElementById("np_corp_table").style.display = "none";
    document.getElementById("Ta").style.Color = "white";
    document.getElementById("Ta").style.backgroundColor = "lightgray";
    document.getElementById("Ta").style.borderColor = "#c8c8c8";
    }
    if(a == 'Ta') {
    document.getElementById("corp_data").style.display = "none";
    document.getElementById("Gra").style.Color = "white";
    document.getElementById("Gra").style.borderColor = "#c8c8c8";
    document.getElementById("Gra").style.backgroundColor = "lightgray";
    document.getElementById("np_corp_table").style.display = "block";
    document.getElementById("Ta").style.backgroundColor = "#ff6a00";
    document.getElementById("Ta").style.borderColor = "#ff6a00";
    }
}

// inve 회사정보 이동 애니메이션

function inve(gicode){
        document.getElementById("Graph1").style.display = "block";
        document.getElementById("Graph2").style.display = "block";
        document.getElementById("corp_link").style.display = "block";
}

function corp_link(gicode){
    setTimeout(function(){location.href = `/corp/${gicode}`}, 200);
}

// chart js
function chart_js(id, type, date, data){
    var context = document
        .getElementById(`${id}`)
        .getContext('2d');
    
    date = str_toDict(date);
    data1 = str_toDict(data1);
    data2 = str_toDict(data2);
    data3 = str_toDict(data3);
    data4 = str_toDict(data4);



    var fi_chart = new Chart(context, {
        type: `${type}`,
        data: {
            labels: [`${date[1]}`, `${date[2]}`, `${date[3]}`, `${date[4]}`],
            datasets: [
                //매출액
                {
                    label: `${data1[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data1[1]), str_toNum(data1[2]), str_toNum(data1[3]), str_toNum(data1[4])
                    ],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 5
                },
                //영업이익
                {
                    label: `${data2[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data2[1]), str_toNum(data2[2]), str_toNum(data2[3]), str_toNum(data2[4])
                    ],
                    backgroundColor: [
                        'rgba(255, 150, 30, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 150, 30, 1)'
                    ],
                    borderWidth: 5
                },
                //세전이익
                {
                    label: `${data3[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data3[1]), str_toNum(data3[2]), str_toNum(data3[3]), str_toNum(data3[4])
                    ],
                    backgroundColor: [
                        'rgba(80, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(80, 99, 255, 1)'
                    ],
                    borderWidth: 5
                },
                //순이익
                {
                    label: `${data4[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data4[1]), str_toNum(data4[2]), str_toNum(data4[3]), str_toNum(data4[4])
                    ],
                    backgroundColor: [
                        'rgba(160, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(160, 99, 255, 1)'
                    ],
                    borderWidth: 5
                },
                //테마 주도주
                {
                    label: `${data3[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data5[1]), str_toNum(data5[2]), str_toNum(data5[3]), str_toNum(data5[4])
                    ],
                    backgroundColor: [
                        'rgba(80, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(80, 99, 255, 1)'
                    ],
                    borderWidth: 5
                },
                //테마 대장주
                {
                    label: `${data3[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data6[1]), str_toNum(data6[2]), str_toNum(data6[3]), str_toNum(data6[4])
                    ],
                    backgroundColor: [
                        'rgba(80, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(80, 99, 255, 1)'
                    ],
                    borderWidth: 5
                },
                //분기별PBR 그래프
                {
                    label: `${data3[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data7[1]), str_toNum(data7[2]), str_toNum(data7[3]), str_toNum(data7[4])
                    ],
                    backgroundColor: [
                        'rgba(80, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(80, 99, 255, 1)'
                    ],
                    borderWidth: 5
                },
                //재무제표 별 적정 그래프
                {
                    label: `${data3[0]}`,
                    fill: false,
                    data: [
                        str_toNum(data7[1]), str_toNum(data7[2]), str_toNum(data7[3]), str_toNum(data7[4])
                    ],
                    backgroundColor: [
                        'rgba(80, 99, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(80, 99, 255, 1)'
                    ],
                    borderWidth: 5
                }
            ]
        },
        options: {
            scales: {
                yAxes: [
                    {
                        ticks: {
                            beginAtZero: true
                        }
                    }
                ]
            }
        }
    });
}

//테마 분류 코드 작성
function theme_code(fics){
    var a;
    if(fics == "IT 서비스"){
        a = "IT 서비스";
        return a;
    } else if(fics == "기계"){
        a = "기계";
        return a;
    } else if(fics == "화학"){
        a = "화학";
        return a;
    } else if(fics == "가스"){
        a = "가스";
        return a;
    } else if(fics == "가정생활용품"){
        a = "가정생활용품";
        return a;
    } else if(fics == "개인생활용품"){
        a = "개인생활용품";
        return a;
    } else if(fics == "건설"){
        a = "건설";
        return a;
    } else if(fics == "건축소재"){
        a = "건축소재";
        return a;
    } else if(fics == "건축자재"){
        a = "건축자재";
        return a;
    } else if(fics == "게임 소프트웨어"){
        a = "게임 소프트웨어";
        return a;
    } else if(fics == "교육"){
        a = "교육";
        return a;
    } else if(fics == "금속 및 광물"){
        a = "금속 및 광물";
        return a;
    } else if(fics == "내구소비재"){
        a = "내구소비재";
        return a;
    } else if(fics == "담배"){
        a = "담배";
        return a;
    } else if(fics == "도소매"){
        a = "도소매";
        return a;
    } else if(fics == "디스플레이 및 관련"){
        a = "디스플레이 및 관련";
        return a;
    } else if(fics == "레저용품"){
        a = "레저용품";
        return a;
    } else if(fics == "무선통신"){
        a = "무선통신";
        return a;
    } else if(fics == "무역"){
        a = "무역";
        return a;
    } else if(fics == "미디어"){
        a = "미디어";
        return a;
    } else if(fics == "바이오"){
        a = "바이오";
        return a;
    } else if(fics == "반도체 및 관련장비"){
        a = "반도체 및 관련장비";
        return a;
    } else if(fics == "백화점"){
        a = "백화점";
        return a;
    } else if(fics == "보안장비"){
        a = "보안장비";
        return a;
    } else if(fics == "보험"){
        a = "보험";
        return a;
    } else if(fics == "복합 산업"){
        a = "복합 산업";
        return a;
    } else if(fics == "부동산"){
        a = "부동산";
        return a;
    } else if(fics == "사무기기"){
        a = "사무기기";
        return a;
    } else if(fics == "상업서비스"){
        a = "상업서비스";
        return a;
    } else if(fics == "상업은행"){
        a = "상업은행";
        return a;
    } else if(fics == "상호저축은해"){
        a = "상호저축은해";
        return a;
    } else if(fics == "석유 및 가스"){
        a = "석유 및 가스";
        return a;
    } else if(fics == "섬유 및 의복"){
        a = "섬유 및 의복";
        return a;
    } else if(fics == "셋톱 박스"){
        a = "셋톱 박스";
        return a;
    } else if(fics == "소비자 금융"){
        a = "소비자 금융";
        return a;
    } else if(fics == "식료품"){
        a = "식료품";
        return a;
    } else if(fics == "에너지 시설 및 서비스"){
        a = "에너지 시설 및 서비스";
        return a;
    } else if(fics == "온라인쇼핑"){
        a = "온라인쇼핑";
        return a;
    } else if(fics == "용기 및 포장"){
        a = "용기 및 포장";
        return a;
    } else if(fics == "운송인프라"){
        a = "운송인프라";
        return a;
    } else if(fics == "유성통신"){
        a = "유성통신";
        return a;
    } else if(fics == "육상운수"){
        a = "육상운수";
        return a;
    } else if(fics == "음료"){
        a = "음료";
        return a;
    } else if(fics == "의료 장비 및 서비스"){
        a = "의료 장비 및 서비스";
        return a;
    } else if(fics == "인터넷 서비스"){
        a = "인터넷 서비스";
        return a;
    } else if(fics == "일반 소프트웨어"){
        a = "일반 소프트웨어";
        return a;
    } else if(fics == "자동차"){
        a = "자동차";
        return a;
    } else if(fics == "자동차부품"){
        a = "자동차부품";
        return a;
    } else if(fics == "전기장비"){
        a = "전기장비";
        return a;
    } else if(fics == "전력"){
        a = "전력";
        return a;
    } else if(fics == "전자 장비 및 기기"){
        a = "전자 장비 및 기기";
        return a;
    } else if(fics == "제약"){
        a = "제약";
        return a;
    } else if(fics == "조선"){
        a = "조선";
        return a;
    } else if(fics == "종이 및 목재"){
        a = "종이 및 목재";
        return a;
    } else if(fics == "증권"){
        a = "증권";
        return a;
    } else if(fics == "창업투자 및 증권"){
        a = "창업투자 및 증권";
        return a;
    } else if(fics == "컴퓨터 및 주변기기"){
        a = "컴퓨터 및 주변기기";
        return a;
    } else if(fics == "통신장비"){
        a = "통신장비";
        return a;
    } else if(fics == "항공운수"){
        a = "항공운수";
        return a;
    } else if(fics == "해상운수"){
        a = "해상운수";
        return a;
    } else if(fics == "호텔 및 레저"){
        a = "호텔 및 레저";
        return a;
    } else if(fics == "휴대폰 및 관련부품"){
        a = "휴대폰 및 관련부품";
        return a
    }
}